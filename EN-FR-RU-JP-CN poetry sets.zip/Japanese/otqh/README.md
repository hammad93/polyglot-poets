与謝蕪村 (Yosa Buson)

Sources:
http://etext.lib.virginia.edu/japanese/buson/haikushu/YosHaik.html	
http://xtf.lib.virginia.edu/xtf/view?docId=Japanese/uvaGenText/tei/YosHaikT.xml 	
http://www.geocities.jp/haikunomori/buson1k.html
