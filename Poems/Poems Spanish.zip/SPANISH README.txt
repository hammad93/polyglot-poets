Num	Name	Dead	Website	Country
1	Miguel de Unamuno	1936	https://www.poemas-del-alma.com/miguel-de-unamuno.htm	Spain
2	Garcia Lorca	1936	https://www.poemas-del-alma.com/federico-garcia-lorca.htm	Spain
3	carolina coronado	1911	http://www.buscapoemas.net/poeta/Carolina-Coronado.htm	espa�a
4	Sor Juana	1695	https://www.poemas-del-alma.com/sor-juana-ines-de-la-cruz.htm	Mejico
5	Francisco de Quevedo	1645	https://www.poemas-del-alma.com/francisco-de-quevedo.htm	Spain
6	Gustavo Adolfo Bequer	1870	https://www.poemas-del-alma.com/gustavo-adolfo-becquer.htm	Spain
7	Jorge Manrique	1479	http://www.buscapoemas.net/poeta/Jorge-Manrique.htm	Spain
8	Lope De Vega	1635	http://www.buscapoemas.net/poeta/Lope-de-Vega.htm	Spain
9	francisco villaespesa	1936	http://www.buscapoemas.net/poeta/Francisco-Villaespesa.htm	Spain
10	Jose de Espronceda	1842	http://www.buscapoemas.net/poeta/Jos%C3%A9-de-Espronceda.htm	Spain
11	Jose Maria de Heredia	1905	http://www.buscapoemas.net/poeta/Jos%C3%A9-Mar%C3%ADa-de-Heredia.htm	Cuba
12	Jose Maria Gabriel y Galan	1905	http://www.buscapoemas.net/poeta/Jos%C3%A9-Mar%C3%ADa-Gabriel-y-Gal%C3%A1n.htm	Espa�a
13	Jose Zorrilla	1893	http://www.buscapoemas.net/poeta/Jos%C3%A9-Zorrilla.htm	Espa�a
14	Juan Boscan	1542	http://www.buscapoemas.net/poeta/Juan-Bosc%C3%A1n.htm	Espa�a
15	Jose Asuncion Silva	1616	http://www.buscapoemas.net/poeta/Jos%C3%A9-Asunci%C3%B3n-Silva.htm	Espa�a
