Name	Dead	Website
Camilo Pessanha	1926	http://www.citador.pt/poemas/a/camilo-pessanha
Mario de Sa-Carneiro	1916	http://www.citador.pt/poemas/a/mario-de-sacarneiro/20
Fiorbela Espanca	1930	http://www.citador.pt/poemas/a/florbela-espanca
Manuel Maria Barbosa	1805	http://www.citador.pt/poemas/a/manuel-maria-barbosa-du-bocage/20
Almeida Garrett	1854	http://www.citador.pt/poemas/flor-de-ventura-almeida-garrett
Antero de Quental	1891	http://www.citador.pt/poemas/na-mao-de-deus-antero-de-quental
Guerra Junqueiro	1923	http://www.citador.pt/poemas/genios-abilio-de-guerra-junqueiro
Cesario Verde	1886	http://www.citador.pt/poemas/a/cesario-verde
Lu�s Vaz de Cam�es	1580	http://www.citador.pt/poemas/a/luis-vaz-de-camoes
Antonio Nobre	1900	http://www.citador.pt/poemas/a/antonio-nobre
Antonio Gomes Leal	1921	http://www.citador.pt/poemas/a/antonio-gomes-leal
Augusto Gil 	1929	https://www.pensador.com/poemas_augusto_gil/
Joao Penha	1919	http://poemas-poestas.blogspot.com.es/search/label/Jo%C3%A3o%20Penha%20-%20Poemas
Bernardim Ribeiro	1552	http://www.citador.pt/poemas/a/bernardim-ribeiro
Fernando Pessoa	1935	https://www.pensador.com/poemas_de_fernando_pessoa/
		
		
		
		http://www.citador.pt/
